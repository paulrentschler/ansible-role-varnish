#define VMOD_ABI_Version "Varnish 3.0.7 f544cd8"
