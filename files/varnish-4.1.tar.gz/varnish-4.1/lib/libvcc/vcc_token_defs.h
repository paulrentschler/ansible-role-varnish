/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit and run generate.py instead
 */
#define	CNUM 128
#define	CSRC 129
#define	CSTR 130
#define	EOI 131
#define	ID 132
#define	T_CAND 133
#define	T_COR 134
#define	T_DEC 135
#define	T_DECR 136
#define	T_DIV 137
#define	T_EQ 138
#define	T_GEQ 139
#define	T_INC 140
#define	T_INCR 141
#define	T_LEQ 142
#define	T_MUL 143
#define	T_NEQ 144
#define	T_NOMATCH 145
#define	T_SHL 146
#define	T_SHR 147
