#define VMOD_ABI_Version "Varnish 4.1.11 61367ed17d08a9ef80a2d42dc84caef79cdeee7a"
