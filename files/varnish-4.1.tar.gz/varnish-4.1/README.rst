Varnish Cache
=============

This is Varnish Cache, the high-performance HTTP accelerator.

Documentation and additional information about Varnish is available on
https://www.varnish-cache.org/

Technical questions about Varnish and this release should be addressed
to <varnish-misc@varnish-cache.org>.  Please see
https://www.varnish-cache.org/trac/wiki/Contributing for how to
contribute patches and report bugs.

Questions about commercial support and services related to Varnish
should be addressed to <sales@varnish-software.com>.
