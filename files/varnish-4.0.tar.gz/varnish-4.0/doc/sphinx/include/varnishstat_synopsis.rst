.. |synopsis| replace::  [-1] [-f <glob>] [-h] [-j] [-l] [-n <dir>] [-t <seconds|off>] [-V] [-x]
