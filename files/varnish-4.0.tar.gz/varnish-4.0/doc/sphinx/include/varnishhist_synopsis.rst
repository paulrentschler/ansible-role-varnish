.. |synopsis| replace::  [-C] [-d] [-g <request|vxid>] [-h] [-L limit] [-n name] [-N filename] [-p period] [-P <size|responsetime|tag:field_num:min:max>] [-q query] [-r filename] [-T seconds] [-V]
