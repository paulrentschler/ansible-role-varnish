.. |synopsis| replace::  [-a] [-C] [-d] [-D] [-F format] [-g <request|vxid>] [-h] [-n name] [-N filename] [-P file] [-q query] [-V] [-w filename]
