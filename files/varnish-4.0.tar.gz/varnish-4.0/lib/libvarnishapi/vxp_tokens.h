/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit and run generate.py instead
 */
#define	EOI 128
#define	T_AND 129
#define	T_EQ 130
#define	T_GEQ 131
#define	T_LEQ 132
#define	T_NEQ 133
#define	T_NOMATCH 134
#define	T_NOT 135
#define	T_OR 136
#define	T_SEQ 137
#define	T_SNEQ 138
#define	T_TRUE 139
#define	VAL 140
