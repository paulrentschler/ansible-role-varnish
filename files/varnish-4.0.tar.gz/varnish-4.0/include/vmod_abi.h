#define VMOD_ABI_Version "Varnish 4.0.5 07eff4c29"
