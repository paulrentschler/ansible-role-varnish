/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit and run generate.py instead
 */

#ifndef VRTSTVTYPE
#define VRTSTVTYPE(ct)
#define VRTSTVTYPEX
#endif
#ifndef VRTSTVVAR
#define VRTSTVVAR(nm, vtype, ctype, dval)
#define VRTSTVVARX
#endif
VRTSTVTYPE(double)
VRTSTVVAR(free_space,	BYTES,	double,	0.)
VRTSTVVAR(used_space,	BYTES,	double,	0.)
VRTSTVTYPE(unsigned)
VRTSTVVAR(happy,	BOOL,	unsigned,	0)

#ifdef VRTSTVTYPEX
#undef VRTSTVTYPEX
#undef VRTSTVTYPE
#endif
#ifdef VRTSTVVARX
#undef VRTSTVVARX
#undef VRTSTVVAR
#endif
